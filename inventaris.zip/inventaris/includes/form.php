<?php /* Partial form: butuh $data, $errors, $title */ ?>
<div class="card">
  <h2><?= e($title) ?></h2>
  <?php if ($errors): ?><div class="alert err"><?= e(t('err_form')) ?></div><?php endif; ?>
  <form method="post" novalidate>
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

    <label><?= e(t('code')) ?></label>
    <input type="text" name="kode_barang" maxlength="20" value="<?= e($data['kode_barang']) ?>">
    <?php if (isset($errors['kode_barang'])): ?><div class="error"><?= e($errors['kode_barang']) ?></div><?php endif; ?>

    <label><?= e(t('name')) ?></label>
    <input type="text" name="nama_barang" maxlength="100" value="<?= e($data['nama_barang']) ?>">
    <?php if (isset($errors['nama_barang'])): ?><div class="error"><?= e($errors['nama_barang']) ?></div><?php endif; ?>

    <label><?= e(t('category')) ?></label>
    <select name="kategori">
      <option value=""><?= e(t('choose')) ?></option>
      <?php foreach (KATEGORI as $k): ?>
        <option value="<?= e($k) ?>" <?= $data['kategori']===$k?'selected':'' ?>><?= e(t('cat_'.$k)) ?></option>
      <?php endforeach; ?>
    </select>
    <?php if (isset($errors['kategori'])): ?><div class="error"><?= e($errors['kategori']) ?></div><?php endif; ?>

    <label><?= e(t('qty')) ?></label>
    <input type="number" name="jumlah" min="0" value="<?= e($data['jumlah']) ?>">
    <?php if (isset($errors['jumlah'])): ?><div class="error"><?= e($errors['jumlah']) ?></div><?php endif; ?>

    <label><?= e(t('price')) ?></label>
    <input type="number" name="harga" min="0" step="0.01" value="<?= e($data['harga']) ?>">
    <?php if (isset($errors['harga'])): ?><div class="error"><?= e($errors['harga']) ?></div><?php endif; ?>

    <label><?= e(t('location')) ?> (<?= e(t('optional')) ?>)</label>
    <input type="text" name="lokasi" maxlength="100" value="<?= e($data['lokasi']) ?>">
    <?php if (isset($errors['lokasi'])): ?><div class="error"><?= e($errors['lokasi']) ?></div><?php endif; ?>

    <p>
      <button class="btn" type="submit"><?= e(t('save')) ?></button>
      <a class="btn gray" href="index.php"><?= e(t('cancel')) ?></a>
    </p>
  </form>
</div>
