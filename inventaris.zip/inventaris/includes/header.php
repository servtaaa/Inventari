<!DOCTYPE html>
<html lang="<?= e($_SESSION['lang']) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e(t('app_title')) ?></title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="topbar">
  <h1><?= e(t('app_title')) ?></h1>
  <nav>
    <?php $back = urlencode(basename($_SERVER['SCRIPT_NAME']) . (isset($_GET['id']) ? '?id=' . (int)$_GET['id'] : '')); ?>
    <span class="lang"><?= e(t('language')) ?>:
      <a href="setlang.php?lang=id&back=<?= $back ?>" class="<?= $_SESSION['lang']==='id'?'active':'' ?>">ID</a> |
      <a href="setlang.php?lang=en&back=<?= $back ?>" class="<?= $_SESSION['lang']==='en'?'active':'' ?>">EN</a>
    </span>
    <?php if (!empty($_SESSION['user_id'])): ?>
      <span><?= e(t('welcome')) ?>, <strong><?= e($_SESSION['nama']) ?></strong></span>
      <a class="btn small" href="logout.php"><?= e(t('logout')) ?></a>
    <?php endif; ?>
  </nav>
</header>
<main class="container">
