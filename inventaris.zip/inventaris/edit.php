<?php
require 'config.php';
require_login();

$id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
if (!$id) { $_SESSION['flash'] = ['type'=>'err','msg'=>'msg_notfound']; header('Location: index.php'); exit; }

$st = $db->prepare('SELECT * FROM barang WHERE id = ?');
$st->bind_param('i', $id);
$st->execute();
$row = $st->get_result()->fetch_assoc();
if (!$row) { $_SESSION['flash'] = ['type'=>'err','msg'=>'msg_notfound']; header('Location: index.php'); exit; }

$data = $row; $errors = [];
$data['harga'] = (string)(float)$row['harga'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) { $_SESSION['flash'] = ['type'=>'err','msg'=>'msg_csrf']; header('Location: index.php'); exit; }
    [$data, $errors] = validate_barang($db, $_POST, $id);
    if (!$errors) {
        $jumlah = (int)$data['jumlah']; $harga = (float)$data['harga'];
        $lokasi = $data['lokasi'] === '' ? null : $data['lokasi'];
        $up = $db->prepare('UPDATE barang SET kode_barang=?, nama_barang=?, kategori=?, jumlah=?, harga=?, lokasi=? WHERE id=?');
        $up->bind_param('sssidsi', $data['kode_barang'], $data['nama_barang'], $data['kategori'], $jumlah, $harga, $lokasi, $id);
        $up->execute();
        $_SESSION['flash'] = ['type'=>'ok','msg'=>'msg_updated'];
        header('Location: index.php'); exit;
    }
}
$title = t('edit_item');
include 'includes/header.php';
include 'includes/form.php';
include 'includes/footer.php';
