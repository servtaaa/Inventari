<?php
require 'config.php';
require_login();

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$q = trim($_GET['q'] ?? '');

if ($q !== '') {
    $like = '%' . $q . '%';
    $st = $db->prepare('SELECT * FROM barang WHERE kode_barang LIKE ? OR nama_barang LIKE ? ORDER BY id DESC');
    $st->bind_param('ss', $like, $like);
    $st->execute();
    $rows = $st->get_result();
} else {
    $rows = $db->query('SELECT * FROM barang ORDER BY id DESC');
}
include 'includes/header.php';
?>
<div class="card">
  <div class="toolbar">
    <h2><?= e(t('item_list')) ?></h2>
    <form method="get">
      <input type="text" name="q" value="<?= e($q) ?>" placeholder="<?= e(t('search')) ?>">
      <button class="btn gray" type="submit"><?= e(t('search_btn')) ?></button>
    </form>
    <a class="btn green" href="create.php">+ <?= e(t('add_item')) ?></a>
  </div>

  <?php if ($flash): ?><div class="alert <?= $flash['type']==='ok'?'ok':'err' ?>"><?= e(t($flash['msg'])) ?></div><?php endif; ?>

  <table>
    <thead><tr>
      <th><?= e(t('no')) ?></th><th><?= e(t('code')) ?></th><th><?= e(t('name')) ?></th><th><?= e(t('category')) ?></th>
      <th class="num"><?= e(t('qty')) ?></th><th class="num"><?= e(t('price')) ?></th><th><?= e(t('location')) ?></th><th><?= e(t('action')) ?></th>
    </tr></thead>
    <tbody>
    <?php if ($rows->num_rows === 0): ?>
      <tr><td colspan="8"><?= e(t('no_data')) ?></td></tr>
    <?php else: $no = 1; while ($r = $rows->fetch_assoc()): ?>
      <tr>
        <td><?= $no++ ?></td>
        <td><?= e($r['kode_barang']) ?></td>
        <td><?= e($r['nama_barang']) ?></td>
        <td><?= e(t('cat_' . $r['kategori'])) ?></td>
        <td class="num"><?= (int)$r['jumlah'] ?></td>
        <td class="num"><?= number_format((float)$r['harga'], 0, ',', '.') ?></td>
        <td><?= e($r['lokasi']) ?></td>
        <td class="actions">
          <a class="btn small" href="edit.php?id=<?= (int)$r['id'] ?>"><?= e(t('edit')) ?></a>
          <form method="post" action="delete.php" onsubmit="return confirm('<?= e(t('confirm_delete')) ?>')">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
            <button class="btn small danger" type="submit"><?= e(t('delete')) ?></button>
          </form>
        </td>
      </tr>
    <?php endwhile; endif; ?>
    </tbody>
  </table>
</div>
<?php include 'includes/footer.php'; ?>
