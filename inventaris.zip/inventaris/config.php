<?php
// Konfigurasi, koneksi database, session, bahasa, dan fungsi bantu
session_start();
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'inventaris');

try {
    $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    die('Koneksi database gagal / Database connection failed.');
}

// Bahasa disimpan di $_SESSION agar konsisten antar halaman
const SUPPORTED_LANGS = ['id', 'en'];
if (empty($_SESSION['lang']) || !in_array($_SESSION['lang'], SUPPORTED_LANGS, true)) {
    $_SESSION['lang'] = 'id';
}
$LANG = require __DIR__ . '/lang/' . $_SESSION['lang'] . '.php';

function t(string $key): string { global $LANG; return $LANG[$key] ?? $key; }
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function require_login(): void {
    if (empty($_SESSION['user_id'])) { header('Location: login.php'); exit; }
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_valid(): bool {
    return isset($_POST['csrf'], $_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $_POST['csrf']);
}

const KATEGORI = ['elektronik', 'alat_tulis', 'furnitur', 'lainnya'];

/**
 * Sanitasi + validasi data barang.
 * Mengembalikan [data_bersih, daftar_error].
 */
function validate_barang(mysqli $db, array $in, int $ignoreId = 0): array {
    $d = [
        'kode_barang' => strtoupper(trim($in['kode_barang'] ?? '')),
        'nama_barang' => trim($in['nama_barang'] ?? ''),
        'kategori'    => trim($in['kategori'] ?? ''),
        'jumlah'      => trim($in['jumlah'] ?? ''),
        'harga'       => trim($in['harga'] ?? ''),
        'lokasi'      => trim($in['lokasi'] ?? ''),
    ];
    $err = [];

    // Kode barang
    if ($d['kode_barang'] === '') {
        $err['kode_barang'] = t('err_required');
    } elseif (!preg_match('/^[A-Z0-9\-]{3,20}$/', $d['kode_barang'])) {
        $err['kode_barang'] = t('err_code_format');
    } else {
        $st = $db->prepare('SELECT id FROM barang WHERE kode_barang = ? AND id <> ?');
        $st->bind_param('si', $d['kode_barang'], $ignoreId);
        $st->execute();
        if ($st->get_result()->num_rows > 0) $err['kode_barang'] = t('err_code_exists');
    }

    // Nama barang
    if ($d['nama_barang'] === '') $err['nama_barang'] = t('err_required');
    elseif (mb_strlen($d['nama_barang']) > 100) $err['nama_barang'] = t('err_too_long');

    // Kategori (switch)
    switch ($d['kategori']) {
        case 'elektronik': case 'alat_tulis': case 'furnitur': case 'lainnya':
            break;
        case '':
            $err['kategori'] = t('err_required'); break;
        default:
            $err['kategori'] = t('err_invalid');
    }

    // Jumlah (integer >= 0)
    if ($d['jumlah'] === '') $err['jumlah'] = t('err_required');
    elseif (filter_var($d['jumlah'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]) === false)
        $err['jumlah'] = t('err_int');

    // Harga (angka >= 0)
    if ($d['harga'] === '') $err['harga'] = t('err_required');
    elseif (!is_numeric($d['harga']) || (float)$d['harga'] < 0) $err['harga'] = t('err_number');

    // Lokasi (opsional)
    if (mb_strlen($d['lokasi']) > 100) $err['lokasi'] = t('err_too_long');

    return [$d, $err];
}
