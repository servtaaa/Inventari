<?php
require 'config.php';
// Hapus data login saja; pilihan bahasa tetap dipertahankan
unset($_SESSION['user_id'], $_SESSION['nama'], $_SESSION['csrf']);
session_regenerate_id(true);
header('Location: login.php');
exit;
