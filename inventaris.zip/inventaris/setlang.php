<?php
require 'config.php';
$lang = $_GET['lang'] ?? '';
if (in_array($lang, SUPPORTED_LANGS, true)) $_SESSION['lang'] = $lang;
// Redirect aman: hanya ke halaman lokal yang dikenal
$back = $_GET['back'] ?? 'index.php';
if (!preg_match('/^(index|login|create|edit)\.php(\?id=\d+)?$/', $back)) $back = 'index.php';
header('Location: ' . $back);
exit;
