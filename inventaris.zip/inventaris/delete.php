<?php
require 'config.php';
require_login();

// Hapus hanya lewat POST + token CSRF
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_valid()) {
    $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
    if ($id) {
        $st = $db->prepare('DELETE FROM barang WHERE id = ?');
        $st->bind_param('i', $id);
        $st->execute();
        $_SESSION['flash'] = ['type'=>'ok','msg'=>'msg_deleted'];
    }
} else {
    $_SESSION['flash'] = ['type'=>'err','msg'=>'msg_csrf'];
}
header('Location: index.php');
exit;
