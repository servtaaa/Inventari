-- Skrip ekspor database: Sistem Informasi Inventaris Barang
CREATE DATABASE IF NOT EXISTS inventaris CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE inventaris;

DROP TABLE IF EXISTS barang;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  nama_lengkap VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE barang (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kode_barang VARCHAR(20) NOT NULL UNIQUE,
  nama_barang VARCHAR(100) NOT NULL,
  kategori ENUM('elektronik','alat_tulis','furnitur','lainnya') NOT NULL,
  jumlah INT NOT NULL DEFAULT 0,
  harga DECIMAL(12,2) NOT NULL DEFAULT 0,
  lokasi VARCHAR(100) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Akun login: admin / admin123 (password disimpan sebagai hash bcrypt)
INSERT INTO users (username, password, nama_lengkap) VALUES
('admin', '$2b$10$IL2ConSG/fFUdTH1M2wj0eM6edsf/gpmyCdlxHKOcWa/z6.Oa/WaS', 'Administrator');

INSERT INTO barang (kode_barang, nama_barang, kategori, jumlah, harga, lokasi) VALUES
('BRG-001','Laptop Lenovo ThinkPad','elektronik',5,12500000,'Lab Komputer'),
('BRG-002','Spidol Whiteboard','alat_tulis',40,8500,'Gudang A'),
('BRG-003','Kursi Kantor','furnitur',12,750000,'Ruang Rapat'),
('BRG-004','Proyektor Epson','elektronik',2,6200000,'Ruang Multimedia');
