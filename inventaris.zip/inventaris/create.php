<?php
require 'config.php';
require_login();

$data = ['kode_barang'=>'','nama_barang'=>'','kategori'=>'','jumlah'=>'','harga'=>'','lokasi'=>''];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) { $_SESSION['flash'] = ['type'=>'err','msg'=>'msg_csrf']; header('Location: index.php'); exit; }
    [$data, $errors] = validate_barang($db, $_POST);
    if (!$errors) {
        $jumlah = (int)$data['jumlah']; $harga = (float)$data['harga'];
        $lokasi = $data['lokasi'] === '' ? null : $data['lokasi'];
        $st = $db->prepare('INSERT INTO barang (kode_barang,nama_barang,kategori,jumlah,harga,lokasi) VALUES (?,?,?,?,?,?)');
        $st->bind_param('sssids', $data['kode_barang'], $data['nama_barang'], $data['kategori'], $jumlah, $harga, $lokasi);
        $st->execute();
        $_SESSION['flash'] = ['type'=>'ok','msg'=>'msg_created'];
        header('Location: index.php'); exit;
    }
}
$title = t('add_item');
include 'includes/header.php';
include 'includes/form.php';
include 'includes/footer.php';
