<?php
return [
 'app_title'=>'Inventory Management System','login'=>'Login','logout'=>'Logout','username'=>'Username','password'=>'Password',
 'login_failed'=>'Incorrect username or password.','welcome'=>'Hello','language'=>'Language',
 'item_list'=>'Item List','add_item'=>'Add Item','edit_item'=>'Edit Item','no_data'=>'No data yet.',
 'no'=>'No','code'=>'Code','name'=>'Item Name','category'=>'Category','qty'=>'Quantity','price'=>'Price (IDR)','location'=>'Location','action'=>'Actions',
 'choose'=>'-- Select --','optional'=>'optional','save'=>'Save','cancel'=>'Cancel','edit'=>'Edit','delete'=>'Delete',
 'confirm_delete'=>'Are you sure you want to delete this record?','search'=>'Search code / name...','search_btn'=>'Search',
 'msg_created'=>'Record added successfully.','msg_updated'=>'Record updated successfully.','msg_deleted'=>'Record deleted successfully.',
 'msg_notfound'=>'Record not found.','msg_csrf'=>'Invalid security token.',
 'cat_elektronik'=>'Electronics','cat_alat_tulis'=>'Stationery','cat_furnitur'=>'Furniture','cat_lainnya'=>'Others',
 'err_required'=>'This field is required.','err_code_format'=>'3-20 characters: letters, digits, or hyphen.','err_code_exists'=>'Code is already in use.',
 'err_too_long'=>'Too long.','err_invalid'=>'Invalid choice.','err_int'=>'Must be an integer >= 0.','err_number'=>'Must be a number >= 0.',
 'err_form'=>'Please check the form fields.',
];
