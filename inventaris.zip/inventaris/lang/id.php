<?php
return [
 'app_title'=>'Sistem Inventaris Barang','login'=>'Masuk','logout'=>'Keluar','username'=>'Nama Pengguna','password'=>'Kata Sandi',
 'login_failed'=>'Nama pengguna atau kata sandi salah.','welcome'=>'Halo','language'=>'Bahasa',
 'item_list'=>'Daftar Barang','add_item'=>'Tambah Barang','edit_item'=>'Ubah Barang','no_data'=>'Belum ada data.',
 'no'=>'No','code'=>'Kode','name'=>'Nama Barang','category'=>'Kategori','qty'=>'Jumlah','price'=>'Harga (Rp)','location'=>'Lokasi','action'=>'Aksi',
 'choose'=>'-- Pilih --','optional'=>'opsional','save'=>'Simpan','cancel'=>'Batal','edit'=>'Ubah','delete'=>'Hapus',
 'confirm_delete'=>'Yakin ingin menghapus data ini?','search'=>'Cari kode / nama...','search_btn'=>'Cari',
 'msg_created'=>'Data berhasil ditambahkan.','msg_updated'=>'Data berhasil diperbarui.','msg_deleted'=>'Data berhasil dihapus.',
 'msg_notfound'=>'Data tidak ditemukan.','msg_csrf'=>'Token keamanan tidak valid.',
 'cat_elektronik'=>'Elektronik','cat_alat_tulis'=>'Alat Tulis','cat_furnitur'=>'Furnitur','cat_lainnya'=>'Lainnya',
 'err_required'=>'Wajib diisi.','err_code_format'=>'3-20 karakter: huruf, angka, atau tanda hubung.','err_code_exists'=>'Kode sudah digunakan.',
 'err_too_long'=>'Terlalu panjang.','err_invalid'=>'Pilihan tidak valid.','err_int'=>'Harus bilangan bulat >= 0.','err_number'=>'Harus angka >= 0.',
 'err_form'=>'Periksa kembali isian form.',
];
