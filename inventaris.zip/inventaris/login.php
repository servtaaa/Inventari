<?php
require 'config.php';
if (!empty($_SESSION['user_id'])) { header('Location: index.php'); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($username === '' || $password === '') {
        $error = t('err_required');
    } else {
        $st = $db->prepare('SELECT id, password, nama_lengkap FROM users WHERE username = ?');
        $st->bind_param('s', $username);
        $st->execute();
        $u = $st->get_result()->fetch_assoc();
        if ($u && password_verify($password, $u['password'])) {
            session_regenerate_id(true);   // cegah session fixation
            $_SESSION['user_id'] = $u['id'];
            $_SESSION['nama'] = $u['nama_lengkap'];
            header('Location: index.php'); exit;
        }
        $error = t('login_failed');
    }
}
include 'includes/header.php';
?>
<div class="card login-box">
  <h2><?= e(t('login')) ?></h2>
  <?php if ($error): ?><div class="alert err"><?= e($error) ?></div><?php endif; ?>
  <form method="post" autocomplete="off">
    <label><?= e(t('username')) ?></label>
    <input type="text" name="username" value="<?= e($_POST['username'] ?? '') ?>" required>
    <label><?= e(t('password')) ?></label>
    <input type="password" name="password" required>
    <p><button class="btn" type="submit"><?= e(t('login')) ?></button></p>
  </form>
  <p class="hint">Demo: admin / admin123</p>
</div>
<?php include 'includes/footer.php'; ?>
