# Sistem Informasi Inventaris Barang (PHP Murni + MySQL)

Aplikasi CRUD inventaris dengan login berbasis `$_SESSION` dan dua bahasa (Indonesia / Inggris).

## Fitur
- Form POST + validasi (if-else & switch) + sanitasi (`htmlspecialchars`, `filter_var`, `trim`)
- CRUD: Create, Read (tabel + pencarian), Update, Delete
- Login/logout dengan `password_hash` / `password_verify`, halaman CRUD terproteksi
- Dual bahasa (ID/EN) tersimpan di `$_SESSION['lang']`
- Keamanan tambahan: prepared statements, token CSRF, `session_regenerate_id`

## Cara Menjalankan
1. Pasang XAMPP / Laragon (PHP 8+, MySQL/MariaDB). Salin folder ini ke `htdocs`.
2. Impor `database/inventaris.sql` lewat phpMyAdmin (atau `mysql -u root < database/inventaris.sql`).
3. Sesuaikan kredensial di `config.php` bila perlu.
4. Buka `http://localhost/inventaris/` lalu login: **admin / admin123**.

## Struktur
```
config.php        koneksi DB, session, bahasa, validasi
login.php, logout.php, setlang.php
index.php         Read (daftar + cari)
create.php, edit.php, delete.php
includes/         header, footer, form
lang/id.php, en.php
assets/style.css
database/inventaris.sql
```
